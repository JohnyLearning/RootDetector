//
//  RootDetection.h
//  RootDetector
//
//  Created by Bhargavi Burugupalli on 11/1/13.
//  Copyright (c) 2013 Bhargavi Burugupalli. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RootDetection : NSObject{
    
}
+ (int)isJailbroken;

@end
