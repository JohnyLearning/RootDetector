//
//  RootDetection.m
//  RootDetector
//
//  Created by Bhargavi Burugupalli on 11/1/13.
//  Copyright (c) 2013 Bhargavi Burugupalli. All rights reserved.
//

#import "RootDetection.h"

@implementation RootDetection
+ (int) isJailbroken
{
#if TARGET_IPHONE_SIMULATOR
    return 0;
#else
    FILE *f = fopen("/bin/bash", "r");
    
    if (errno == ENOENT)
    {
        // device is NOT jailbroken
        fclose(f);
        return 0;
    }
    else {
        // device IS jailbroken
        fclose(f);
        return 1;
    }
#endif
}

@end
